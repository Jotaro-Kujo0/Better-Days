extends "res://scripts/chapter_controller.gd"
## Boat push beat (on boat_push.tscn ChapterRoot): press ACTION 10x to push the boat
## to the water, then the chapter advances to fishing. Extends the chapter controller
## so the mood baseline + intro dialogue still run; the ExitZone is disabled —
## the boat push is the only way forward.

@export var presses_needed := 10
var presses := 0
var _done := false

@onready var boat: Node3D = $Boat
@onready var prompt: Label = $CanvasLayer/Prompt

func _ready() -> void:
	super._ready()
	var exit_zone := get_node_or_null("ExitZone") as Area3D
	if exit_zone:
		exit_zone.set_deferred("monitoring", false)
	prompt.text = "Push! 0 / %d" % presses_needed

func _unhandled_input(event: InputEvent) -> void:
	if _done or not event.is_action_pressed("interact"):
		return
	if DialogueManager.active:
		return
	presses += 1
	boat.position.z -= 0.6
	prompt.text = "Push! %d / %d" % [presses, presses_needed]
	if presses >= presses_needed:
		_done = true
		prompt.hide()
		await get_tree().create_timer(1.0).timeout
		SceneRouter.goto("fishing")
