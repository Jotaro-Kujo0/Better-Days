extends Node
## ChapterController — mood baseline on entry, dialogue trigger, exit zone, cutscene helper.

@export var next_chapter := ""
@export var dialogue_key := ""
@export var entry_color := 1.0
@export var entry_darkness := 0.0

var _dialogue_started := false
var _cutscene_running := false

@onready var player: Node = get_tree().get_first_node_in_group("player")

func _ready() -> void:
	ColorFilter.set_instant(entry_color, entry_darkness)
	SceneRouter.fade_in(1.0)
	var trig := get_node_or_null("DialogueTrigger") as Area3D
	if trig and dialogue_key != "":
		trig.body_entered.connect(_on_dialogue_trigger)
	var exit_zone := get_node_or_null("ExitZone") as Area3D
	if exit_zone and next_chapter != "":
		exit_zone.body_entered.connect(_on_exit_zone)

func _on_dialogue_trigger(body: Node3D) -> void:
	if _dialogue_started or body.is_in_group("player") == false:
		return
	if DialogueManager.active:
		return
	_dialogue_started = true
	DialogueManager.start_dialogue(dialogue_key)

func _on_exit_zone(body: Node3D) -> void:
	if body.is_in_group("player") == false:
		return
	if DialogueManager.active:
		return
	SceneRouter.goto(next_chapter)

func run_cutscene(anim_name := "intro") -> void:
	if _cutscene_running:
		return
	_cutscene_running = true
	if player:
		player.can_move = false
		player.set_process_input(false)
		player.set_process_unhandled_input(false)
	var cut_cam := get_node_or_null("CutsceneCamera") as Camera3D
	if cut_cam:
		cut_cam.make_current()
	var anim := get_node_or_null("AnimationPlayer") as AnimationPlayer
	if anim and anim.has_animation(anim_name):
		anim.play(anim_name)
		await anim.animation_finished
	if cut_cam and player:
		var pcam := player.get_node_or_null("Camera3D") as Camera3D
		if pcam:
			pcam.make_current()
	if player:
		player.can_move = true
		player.set_process_input(true)
		player.set_process_unhandled_input(true)
	_cutscene_running = false
