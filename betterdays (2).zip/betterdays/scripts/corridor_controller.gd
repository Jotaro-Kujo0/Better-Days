extends "res://scripts/chapter_controller.gd"
## Corridor chapter: the ExitZone stays locked until the player reads
## `reads_needed` of the 5 lore objects.

@export var reads_needed := 3
var _reads := 0

func _ready() -> void:
	super._ready()
	for obj in get_tree().get_nodes_in_group("lore_objects"):
		obj.was_read.connect(_on_read)

func _on_read() -> void:
	_reads += 1
	if _reads >= reads_needed:
		var exit_zone := get_node_or_null("ExitZone") as Area3D
		if exit_zone:
			exit_zone.set_deferred("monitoring", true)
