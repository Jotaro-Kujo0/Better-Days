extends Node
## Fishing chapter: intro dialogue → 2 scripted fails → gold bar → 3 catches → corridor.

const MinigameScene := preload("res://ui/fishing_minigame.tscn")
const BEHAVIORS := [0, 4, 2, 1, 3]        # MIXED, DART, SINKER, SMOOTH, FLOATER
const DIFFICULTIES := [6.0, 8.0, 3.0, 3.0, 3.0]

@export var entry_color := 0.2
@export var entry_darkness := 0.4

var attempts := 0
var catches := 0

@onready var player: Node = get_tree().get_first_node_in_group("player")

func _ready() -> void:
	ColorFilter.set_instant(entry_color, entry_darkness)
	SceneRouter.fade_in(1.0)
	_intro()

func _intro() -> void:
	await get_tree().create_timer(1.2).timeout
	DialogueManager.start_dialogue("fishing_intro")
	await DialogueManager.finished
	_run_rounds()

func _lock(on: bool) -> void:
	if player == null:
		return
	player.can_move = not on
	player.set_process_input(not on)
	player.set_process_unhandled_input(not on)

func _run_rounds() -> void:
	_lock(true)
	var mg := MinigameScene.instantiate()
	add_child(mg)
	while catches < 3:
		attempts += 1
		var i: int = mini(attempts, 5) - 1
		mg.fish_difficulty = DIFFICULTIES[i]
		mg.start_round(BEHAVIORS[i], attempts <= 2, attempts > 2)
		var caught: bool = await mg.round_finished
		if caught:
			catches += 1
			ColorFilter.set_color(minf(0.2 + catches * 0.2, 0.8), 2.0)
			if catches < 3:
				DialogueManager.start_dialogue("fishing_catch")
				await DialogueManager.finished
		else:
			ColorFilter.set_darkness(minf(0.4 + attempts * 0.1, 0.8), 2.0)
			DialogueManager.start_dialogue("fishing_fail_%d" % mini(attempts, 2))
			await DialogueManager.finished
	mg.queue_free()
	DialogueManager.start_dialogue("fishing_end")
	await DialogueManager.finished
	_lock(false)
	SceneRouter.goto("corridor")
