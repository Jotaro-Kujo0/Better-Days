extends Area3D
## Readable lore object: walk in, press ACTION, play its one-shot dialogue once.

signal was_read

@export var dialogue_key := ""
var _read := false
var _player_inside := false

func _ready() -> void:
	body_entered.connect(func(b): if b.is_in_group("player"): _player_inside = true)
	body_exited.connect(func(b): if b.is_in_group("player"): _player_inside = false)

func _unhandled_input(event: InputEvent) -> void:
	if _read or not _player_inside or not event.is_action_pressed("interact"):
		return
	if DialogueManager.active:
		return
	_read = true
	was_read.emit()
	if dialogue_key != "":
		DialogueManager.start_dialogue(dialogue_key)
