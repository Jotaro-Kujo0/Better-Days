extends Node
## SceneRouter — black-fade transitions between chapter scenes.

const CHAPTERS := {
	"office": "res://scenes/chapters/office.tscn",
	"home_door": "res://scenes/chapters/home_door.tscn",
	"bedroom": "res://scenes/chapters/bedroom.tscn",
	"beach": "res://scenes/chapters/beach.tscn",
	"boat_push": "res://scenes/chapters/boat_push.tscn",
	"fishing": "res://scenes/chapters/fishing.tscn",
	"corridor": "res://scenes/chapters/corridor.tscn",
	"kitchen": "res://scenes/chapters/kitchen.tscn",
}

var _fade_layer: CanvasLayer
var _fade_rect: ColorRect
var _transitioning := false

func _ready() -> void:
	_fade_layer = CanvasLayer.new()
	_fade_layer.layer = 1000
	_fade_rect = ColorRect.new()
	_fade_rect.color = Color(0, 0, 0, 1)
	_fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	_fade_layer.add_child(_fade_rect)
	add_child(_fade_layer)

func goto(key: String, duration := 0.6) -> void:
	if _transitioning:
		return
	if not CHAPTERS.has(key):
		push_error("SceneRouter: unknown chapter '%s'" % key)
		return
	_transitioning = true
	var tw := create_tween()
	tw.tween_property(_fade_rect, "color:a", 1.0, duration)
	await tw.finished
	var err := get_tree().change_scene_to_file(CHAPTERS[key])
	if err != OK:
		push_error("SceneRouter: change_scene_to_file failed (%s)" % str(err))
		_transitioning = false
		return
	await get_tree().process_frame
	await get_tree().process_frame
	fade_in(duration)
	_transitioning = false

func fade_in(duration := 1.0) -> void:
	var tw := create_tween()
	tw.tween_property(_fade_rect, "color:a", 0.0, duration)
