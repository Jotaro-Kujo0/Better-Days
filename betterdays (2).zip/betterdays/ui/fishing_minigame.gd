extends Control
## Stardew-style vertical fishing bar. Hold ACTION to push bar up, release to fall.

signal round_finished(caught: bool)

enum Behavior { MIXED, SMOOTH, SINKER, FLOATER, DART }

@export var action_name := "interact"
@export var player_bar_height := 60.0
@export var fish_difficulty := 5.0
@export var catch_fill_rate := 10.0
@export var catch_drain_rate := 15.0
@export var hold_accel := 500.0
@export var gravity_accel := 300.0

const MARGIN := 8.0

var bar_velocity := 0.0
var fish_velocity := 0.0
var fish_dir := -1.0
var fish_timer := 0.0
var elapsed := 0.0
var progress := 30.0
var _behavior := Behavior.MIXED
var _fail_at := -1.0
var _running := false

@onready var panel: Panel = $Panel
@onready var player_bar: ColorRect = $Panel/PlayerBar
@onready var fish_icon: ColorRect = $Panel/Fish
@onready var meter: ProgressBar = $Panel/CatchMeter

func _ready() -> void:
	visible = false

func start_round(behavior: Behavior, scripted_fail := false, help_mode := false) -> void:
	_behavior = behavior
	player_bar.color = Color(1.0, 0.84, 0.0) if help_mode else Color(0.2, 0.8, 0.3)
	_fail_at = randf_range(80.0, 95.0) if scripted_fail else -1.0
	progress = 30.0
	elapsed = 0.0
	bar_velocity = 0.0
	fish_velocity = -40.0
	fish_timer = 0.0
	player_bar.size.y = player_bar_height
	player_bar.position = Vector2(24.0, panel.size.y * 0.5 - player_bar_height * 0.5)
	fish_icon.position = Vector2(panel.size.x * 0.5 - 12.0, panel.size.y * 0.5 - 12.0)
	meter.value = progress
	visible = true
	_running = true

func _process(delta: float) -> void:
	if not _running:
		return
	elapsed += delta
	_move_bar(delta)
	_move_fish(delta)
	_update_meter(delta)

func _move_bar(delta: float) -> void:
	var pushing := Input.is_action_pressed(action_name) \
			or Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
	if pushing:
		bar_velocity -= hold_accel * delta
	else:
		bar_velocity += gravity_accel * delta
	var y := player_bar.position.y + bar_velocity * delta
	var max_y := panel.size.y - player_bar.size.y - MARGIN
	if y >= max_y:
		y = max_y
		if bar_velocity > 0.0:
			bar_velocity = -bar_velocity * 0.3
	elif y <= MARGIN:
		y = MARGIN
		bar_velocity = 0.0
	player_bar.position.y = y

func _move_fish(delta: float) -> void:
	var speed := 40.0 + fish_difficulty * 25.0
	match _behavior:
		Behavior.MIXED:
			fish_timer -= delta
			if fish_timer <= 0.0:
				fish_dir = -1.0 if randf() < 0.5 else 1.0
				fish_timer = randf_range(0.5, 2.0)
			fish_velocity = fish_dir * speed
		Behavior.SMOOTH:
			fish_velocity = cos(elapsed * 0.8) * speed * 0.6
		Behavior.SINKER:
			fish_velocity += gravity_accel * delta * (0.6 + fish_difficulty * 0.06)
			fish_velocity = clampf(fish_velocity, -speed, speed * 1.5)
		Behavior.FLOATER:
			fish_velocity -= gravity_accel * delta * (0.6 + fish_difficulty * 0.06)
			fish_velocity = clampf(fish_velocity, -speed * 1.5, speed)
		Behavior.DART:
			fish_timer -= delta
			if fish_timer <= 0.0:
				fish_dir = -1.0 if randf() < 0.5 else 1.0
				fish_timer = randf_range(0.15, 0.4)
			fish_velocity = fish_dir * speed * 2.0
	var y := fish_icon.position.y + fish_velocity * delta
	var max_y := panel.size.y - fish_icon.size.y - MARGIN
	if y >= max_y:
		y = max_y
		fish_velocity = -absf(fish_velocity) * 0.5
	elif y <= MARGIN:
		y = MARGIN
		fish_velocity = absf(fish_velocity) * 0.5
	fish_icon.position.y = y

func _fish_inside_bar() -> bool:
	var center := fish_icon.position.y + fish_icon.size.y * 0.5
	return center >= player_bar.position.y \
			and center <= player_bar.position.y + player_bar.size.y

func _update_meter(delta: float) -> void:
	progress += (catch_fill_rate if _fish_inside_bar() else -catch_drain_rate) * delta
	if _fail_at >= 0.0 and progress >= _fail_at:
		_finish(false)
		return
	meter.value = clampf(progress, 0.0, 100.0)
	if progress >= 100.0:
		_finish(true)
	elif progress <= 0.0:
		_finish(false)

func _finish(caught: bool) -> void:
	_running = false
	meter.value = clampf(progress, 0.0, 100.0)
	await get_tree().create_timer(0.6).timeout
	round_finished.emit(caught)
