class_name DialogueData
extends RefCounted
# No node attached, no autoload. Global class: use DialogueData.get_dialogue("key") anywhere.

const DIALOGUES := {
	"office": [
		{"name": "Patron", "text": "Bunu tekrar yapabileceğini düşünüyor musun?", "color": 0.7, "darkness": 0.2},
		{"name": "Patron", "text": "Seni bir süredir takip ediyorum... Bu çalışma değil.", "color": 0.4, "darkness": 0.32},
		{"name": "Patron", "text": "Kovuldun. Eşyalarını topla.", "color": 0.15, "darkness": 0.45},
	],
	"door": [
		{"name": "Baba", "text": "Oğlum... gelmişsin sonunda.", "darkness": 0.45},
		{"name": "Oğul", "text": "Baba... içeri girebilir miyim?", "darkness": 0.35},
		{"name": "Baba", "text": "Evet oğlum, burası senin evin. Hep öyleydi.", "darkness": 0.28},
	],
	"phone": [
		{"name": "", "text": "(Eski mesajlar... kimse yazmıyor artık.)", "darkness": 0.68},
		{"name": "", "text": "(Belki de hiç kimsenin aklına gelmiyorumdur.)", "darkness": 0.74},
	],
	"beach_memory": [
		{"name": "Baba", "text": "Şu çitlerin arkasında... sen çocukken orada balık tutardık.", "color": 0.12, "darkness": 0.35},
		{"name": "Baba", "text": "Denize ilk attığın oltayı hatırlıyor musun?", "color": 0.2, "darkness": 0.28},
	],
	"boat_catch_1": [
		{"name": "Baba", "text": "Kötü günler geçirdiğini biliyorum oğlum.", "color": 0.25, "darkness": 0.4},
		{"name": "Baba", "text": "Ama umudunu asla kaybetme. Sen bizim için çok önemlisin.", "color": 0.3, "darkness": 0.32},
	],
	"boat_catch_2": [
		{"name": "Baba", "text": "Görüyor musun? Birlikte daha iyiyiz.", "color": 0.45, "darkness": 0.2},
	],
	"boat_final": [
		{"name": "Baba", "text": "Daha iyi günlere bak oğlum.", "color": 0.7, "darkness": 0.05},
	],
	"obj_frame": [
		{"name": "", "text": "(Çerçevedeki fotoğraf: ben, baba ve deniz.)", "color": 0.63},
	],
	"obj_lamp": [
		{"name": "", "text": "(Eski lamba hâlâ aynı yerde duruyor.)"},
	],
	"obj_trophy": [
		{"name": "", "text": "(Balık yarışması kupası. En çok bu evi severdim.)", "color": 0.65},
	],
	"home_door": [
		{"name": "Dad", "text": "You came back, son.", "color": 0.5, "darkness": 0.2},
		{"name": "Dad", "text": "The door was never locked for you.", "color": 0.6, "darkness": 0.2},
		{"name": "Dad", "text": "Come inside. It is still your home.", "color": 0.7, "darkness": 0.2},
	],
	"bedroom": [
		{"name": "Dad", "text": "Your room is just as you left it.", "color": 0.3, "darkness": 0.3},
		{"name": "Dad", "text": "It feels smaller now, does it not?", "color": 0.15, "darkness": 0.5},
		{"name": "Dad", "text": "Rest tonight. Tomorrow we walk to the sea.", "color": 0.3, "darkness": 0.35},
	],
	"beach": [
		{"name": "Dad", "text": "Do you remember this shore?", "color": 0.2, "darkness": 0.2},
		{"name": "Dad", "text": "You cast your first line right here.", "color": 0.35, "darkness": 0.2},
		{"name": "Dad", "text": "The sea keeps every summer we gave it.", "color": 0.5, "darkness": 0.2},
	],
	"boat_push": [
		{"name": "Dad", "text": "Help me push the boat out.", "color": 0.3, "darkness": 0.2},
		{"name": "Dad", "text": "Together now... it still remembers your hands.", "color": 0.35, "darkness": 0.2},
	],
	"fishing": [
		{"name": "Dad", "text": "Patience, son. The fish feel your hurry.", "color": 0.25, "darkness": 0.4},
		{"name": "Dad", "text": "Breathe with the water. Nothing else exists.", "color": 0.15, "darkness": 0.6},
		{"name": "Dad", "text": "Look -- you caught it. You caught it!", "color": 0.6, "darkness": 0.2},
	],
	"corridor": [
		{"name": "Dad", "text": "Walk with me a little further.", "color": 0.45, "darkness": 0.2},
		{"name": "Dad", "text": "The kitchen is at the end. It always was.", "color": 0.45, "darkness": 0.2},
	],
	"kitchen": [
		{"name": "Dad", "text": "Everything is ready, like it used to be.", "color": 0.5, "darkness": 0.1},
		{"name": "Dad", "text": "The table is set for both of us.", "color": 0.7, "darkness": 0.1},
		{"name": "Dad", "text": "Welcome home. This time we stay.", "color": 1.0, "darkness": 0.1},
	],
	"fishing_intro": [
		{"name": "Dad", "text": "Here. Your grandfather's rod.", "color": 0.2, "darkness": 0.4},
		{"name": "Dad", "text": "Cast it out. Let the water hold it.", "color": 0.22, "darkness": 0.4},
		{"name": "Dad", "text": "The rest is patience. We have time.", "color": 0.25, "darkness": 0.38},
	],
	"fishing_fail_1": [
		{"name": "Dad", "text": "It slipped away. That is the sea.", "color": 0.22, "darkness": 0.5},
		{"name": "Dad", "text": "You did not lose it. It is still out there.", "color": 0.25, "darkness": 0.48},
		{"name": "Dad", "text": "Again. I am right here.", "color": 0.28, "darkness": 0.45},
	],
	"fishing_fail_2": [
		{"name": "Dad", "text": "Stay with me, son.", "color": 0.3, "darkness": 0.5},
		{"name": "Dad", "text": "I will hold the rod with you this time.", "color": 0.45, "darkness": 0.4},
		{"name": "Dad", "text": "Feel that? We are stronger together.", "color": 0.55, "darkness": 0.35},
	],
	"fishing_catch": [
		{"name": "Dad", "text": "There! You held on!", "color": 0.45, "darkness": 0.25},
	],
	"fishing_end": [
		{"name": "Dad", "text": "Three fish. Did you count your hands shaking?", "color": 0.6, "darkness": 0.2},
		{"name": "Dad", "text": "They are calmer now. So are you.", "color": 0.7, "darkness": 0.15},
		{"name": "Dad", "text": "Look out for better days, son. They come back with the tide.", "color": 0.8, "darkness": 0.1},
	],
	"beach_road": [
		{"name": "Dad", "text": "We took this road every summer.", "color": 0.25, "darkness": 0.2},
		{"name": "Dad", "text": "You always ran ahead and waited at the corner.", "color": 0.4, "darkness": 0.2},
		{"name": "Dad", "text": "I never minded the waiting. I knew you would come back.", "color": 0.55, "darkness": 0.2},
	],
	"lore_photo": [
		{"name": "", "text": "(The three of us at the pier. I do not remember this day -- but I remember being happy.)", "color": 0.5, "darkness": 0.15},
	],
	"lore_trophy": [
		{"name": "", "text": "(Second place, junior fishing derby. Dad framed it anyway.)", "color": 0.55, "darkness": 0.1},
	],
	"lore_radio": [
		{"name": "", "text": "(The old radio. Every Sunday morning, the same sea-report program.)", "color": 0.45, "darkness": 0.15},
	],
	"lore_disk": [
		{"name": "", "text": "(Old disk burned with some code) I used to work on these alot. Maybe I'll get back to it.", "color": 0.6, "darkness": 0.1},
	],
	"lore_car": [
		{"name": "", "text": "(the old house cat) How you doing bud? Been a long time since I last saw you.", "color": 0.4, "darkness": 0.2},
	],
}

static func get_dialogue(key: String) -> Array:
	var v: Variant = DIALOGUES.get(key, [])
	return v if v is Array else []
