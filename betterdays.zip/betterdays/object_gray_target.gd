@tool
extends MeshInstance3D
## Adds this mesh to group "gray_targets" and wires the grayscale overlay next_pass. Idempotent.

const SHADER_PATH := "res://object_gray.gdshader"

func _ready() -> void:
	add_to_group("gray_targets")
	_wire.call_deferred()

func _wire() -> void:
	for i in get_surface_override_material_count():
		var base := get_active_material(i)
		if base == null:
			continue
		var override := get_surface_override_material(i)
		if override is ShaderMaterial and override.next_pass != null \
				and override.next_pass is ShaderMaterial \
				and override.next_pass.shader != null \
				and override.next_pass.shader.resource_path == SHADER_PATH:
			continue  # already wired
		var overlay := ShaderMaterial.new()
		overlay.shader = load(SHADER_PATH)
		var sm := base as StandardMaterial3D
		if sm:
			overlay.set_shader_parameter("base_albedo", sm.albedo_color)
			var tex := sm.albedo_texture
			overlay.set_shader_parameter("has_base_tex", tex != null)
			if tex:
				overlay.set_shader_parameter("base_tex", tex)
		if override == null:
			override = base.duplicate()
			set_surface_override_material(i, override)
		override.next_pass = overlay
