extends Node

const SCENES := {
	"office":      {"path": "res://scenes/office.tscn",        "color": 1.0,  "dark": 0.10},
	"home_intro":  {"path": "res://scenes/home_intro.tscn",    "color": 0.0,  "dark": 0.55},
	"beach_walk":  {"story": "starts color 0.05/dark 0.45",    "color": 0.05, "dark": 0.45},
	"boat_fishing":{"path": "res://scenes/boat_fishing.tscn",  "color": 0.10, "dark": 0.30},
	"home_ending": {"path": "res://scenes/home_ending.tscn",   "scene": "loads at corridor 0.60/0.05", "color": 0.60, "dark": 0.05},
	"credits":     {"path": "res://scenes/credits.tscn",       "color": 0.60, "dark": 0.0},
}

func goto(key: String) -> void:
	var data: Dictionary = SCENES[key]
	var tw := create_tween()
	tw.tween_method(func(v): ColorFilter.set_instant(v, ColorFilter.darkness), 0.0, 1.0, 0.6)  # fade via overlay
	await tw.finished
	get_tree().change_scene_to_file(data["path"])
	await get_tree().process_frame
	ColorFilter.set_instant(data["color"], data["dark"])
	ColorFilter.clear_spot()
	# fade back in
