extends Node3D

@export var spot_radius := 0.15
@export var spot_strength := 0.30

func _process(_delta: float) -> void:
	var cam := get_viewport().get_camera_3d()
	if cam == null or cam.is_position_behind(global_position):
		ColorFilter.clear_spot()
		return
	var sp := cam.unproject_position(global_position + Vector3.UP * 0.9)   # chest height
	var vp := get_viewport().get_visible_rect().size
	var uv := sp / vp
	if uv.x < -0.2 or uv.x > 1.2 or uv.y < -0.2 or uv.y > 1.2:
		ColorFilter.clear_spot()
		return
	ColorFilter.set_spot(uv, spot_radius, spot_strength)
