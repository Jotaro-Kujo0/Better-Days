extends CanvasLayer
## ColorFilter — panic mood system.
## mood 0 = full color, wide FOV | 0.5 = grayscale | 1 = near-black + static + tunnel FOV.

const NORMAL_FOV := 70.0
const PANIC_FOV := 40.0
const FOV_SMOOTH_SPEED := 3.5 # higher = snappier glide (exponential follow)

var _color := 0.0
var _darkness := 0.0
var _target := 0.5
var _tween: Tween

var _tracked_camera: Camera3D
var _camera_base_fov := NORMAL_FOV
var _fov_current := NORMAL_FOV

func _ready() -> void:
	add_to_group("color_filter")
	set_instant(_color, _darkness)

func _get_mat() -> ShaderMaterial:
	var rect := get_node_or_null("ColorRect") as ColorRect
	if rect and rect.material is ShaderMaterial:
		return rect.material as ShaderMaterial
	return null

func _apply(v: float) -> void:
	var m := _get_mat()
	if m:
		m.set_shader_parameter("mood", v)

func set_mood(v: float, duration := 1.5) -> void:
	_target = clampf(v, 0.0, 1.0)
	if _tween and _tween.is_valid():
		_tween.kill()
	if duration <= 0.0:
		_apply(_target)
		return
	var cur := 0.0
	var m := _get_mat()
	if m:
		var p: Variant = m.get_shader_parameter("mood")
		cur = float(p) if p != null else 0.0
	_tween = create_tween()
	_tween.tween_method(_apply, cur, _target, duration)

func set_color(c: float, duration := 2.0) -> void:
	_color = clampf(c, 0.0, 1.0)
	set_mood(0.5 * (1.0 - _color) + 0.5 * _darkness, duration)

func set_darkness(d: float, duration := 1.5) -> void:
	_darkness = clampf(d, 0.0, 1.0)
	set_mood(0.5 * (1.0 - _color) + 0.5 * _darkness, duration)

func set_instant(c: float, d: float) -> void:
	_color = clampf(c, 0.0, 1.0)
	_darkness = clampf(d, 0.0, 1.0)
	set_mood(0.5 * (1.0 - _color) + 0.5 * _darkness, 0.0)

func _process(delta: float) -> void:
	var player := get_tree().get_first_node_in_group("player")
	if player == null:
		return
	var cam := player.get_node_or_null("Camera3D") as Camera3D
	if cam == null or cam.projection != Camera3D.PROJECTION_PERSPECTIVE:
		return
	if cam != _tracked_camera:
		_tracked_camera = cam
		_camera_base_fov = cam.fov
		_fov_current = cam.fov # don't glide from the previous camera's value
	# smoothstep ease + exponential follow: FOV always glides toward the goal,
	# frame-rate independent, even when _target itself jumps instantly.
	var desired := lerpf(_camera_base_fov, PANIC_FOV, smoothstep(0.0, 1.0, _target))
	var k := 1.0 - exp(-FOV_SMOOTH_SPEED * delta)
	_fov_current = lerpf(_fov_current, desired, k)
	if absf(_fov_current - desired) < 0.01:
		_fov_current = desired
	cam.fov = _fov_current

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_PAGEUP:
			set_mood(_target + 0.05, 0.2)
		elif event.keycode == KEY_PAGEDOWN:
			set_mood(_target - 0.05, 0.2)
		elif event.keycode == KEY_1:
			set_mood(0.0, 0.3)
		elif event.keycode == KEY_2:
			set_mood(0.5, 0.3)
		elif event.keycode == KEY_3:
			set_mood(1.0, 0.3)
		elif event.keycode == KEY_G:
			ObjectGray.set_enabled(not ObjectGray.enabled)
