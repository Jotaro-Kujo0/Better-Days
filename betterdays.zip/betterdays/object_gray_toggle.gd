class_name ObjectGray
extends RefCounted

static var enabled := false

static func set_enabled(on: bool) -> void:
	enabled = on
	RenderingServer.global_shader_parameter_set("object_gray", 1.0 if on else 0.0)
