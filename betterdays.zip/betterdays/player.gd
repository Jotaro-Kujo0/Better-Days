extends CharacterBody3D

const MOUSE_SENSITIVITY := 0.005
const WALK_SPEED := 5.0
const RUN_SPEED := 8.0
const JUMP_VELOCITY := 4.5
const MOUSE_SMOOTHING := 12.0
const BOB_AMPLITUDE := 0.08
const BOB_FREQUENCY := 3.0
const BOB_SMOOTHING := 8.0
const RUN_FREQ_MULT := 1.6
const RUN_AMP_MULT := 1.15

var can_move := true
var look_enabled := true
var bob_enabled := true
var bob_time := 0.0
var bob_offset := 0.0
var mouse_accum := Vector2.ZERO
var cam_base_position: Vector3

@onready var cam: Camera3D = $Camera3D
@onready var ray: RayCast3D = $Camera3D/RayCast3D

func _ready() -> void:
	add_to_group("player")
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	cam_base_position = cam.position
	ray.add_exception(self)

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("interact"):
		_try_interact()
	if event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED else Input.MOUSE_MODE_CAPTURED

func _input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		mouse_accum += event.relative * MOUSE_SENSITIVITY

func _apply_mouse_look(delta: float) -> void:
	if not look_enabled:
		mouse_accum = Vector2.ZERO
		return
	if mouse_accum == Vector2.ZERO:
		return
	var f := 1.0 - exp(-MOUSE_SMOOTHING * delta)
	rotate_y(-mouse_accum.x * f)
	cam.rotation.x = clampf(cam.rotation.x - mouse_accum.y * f, deg_to_rad(-85), deg_to_rad(85))
	mouse_accum *= 1.0 - f

func _try_interact() -> void:
	if not ray.is_colliding():
		return
	var hit = ray.get_collider()
	if hit is Node:
		var target := _find_interactable(hit)
		if target != null:
			target.call("interact", self)

func _find_interactable(node: Node) -> Node:
	var current := node
	for i in 8:
		if current == null:
			return null
		if current.is_in_group("interactable") and current.has_method("interact"):
			return current
		current = current.get_parent()
	return null

func update_head_bob(delta: float, input_dir: Vector2, running: bool) -> void:
	var target := 0.0
	if bob_enabled and is_on_floor() and input_dir.length() > 0.1:
		var freq := BOB_FREQUENCY * (RUN_FREQ_MULT if running else 1.0)
		var amp := BOB_AMPLITUDE * (RUN_AMP_MULT if running else 1.0)
		bob_time += delta * freq
		var speed_ratio := clampf(Vector2(velocity.x, velocity.z).length() / WALK_SPEED, 0.0, 1.6)
		target = sin(bob_time * TAU) * amp * speed_ratio
	bob_offset = lerpf(bob_offset, target, 1.0 - exp(-BOB_SMOOTHING * delta))
	cam.position = cam_base_position + Vector3(0.0, bob_offset, 0.0)

func _physics_process(delta: float) -> void:
	_apply_mouse_look(delta)
	if not is_on_floor():
		velocity += get_gravity() * delta
	if can_move and Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY
	var running := can_move and Input.is_action_pressed("run")
	var current_speed := RUN_SPEED if running else WALK_SPEED
	var input_dir := Input.get_vector("a", "d", "w", "s") if can_move else Vector2.ZERO
	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	if direction:
		velocity.x = direction.x * current_speed
		velocity.z = direction.z * current_speed
	else:
		velocity.x = move_toward(velocity.x, 0, WALK_SPEED)
		velocity.z = move_toward(velocity.z, 0, WALK_SPEED)
	update_head_bob(delta, input_dir, running)
	move_and_slide()
