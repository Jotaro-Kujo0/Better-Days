extends Node

signal finished

const CHAR_SPEED := 30.0

var lines: Array = []
var index := 0
var active := false
var advance_armed := false
var _char_accum := 0.0

@onready var name_label: Label = $DialogueUI/Panel/VBox/NameLabel
@onready var text_label: RichTextLabel = $DialogueUI/Panel/VBox/Text
@onready var hint_label: Label = $DialogueUI/Panel/VBox/Hint

func _ready() -> void:
	$DialogueUI.visible = false

func start_dialogue(key: String) -> void:
	if active:
		return
	lines = DialogueData.get_dialogue(key)
	if lines.is_empty():
		push_error("No dialogue named: " + key)
		return
	index = 0
	active = true
	advance_armed = false
	$DialogueUI.visible = true
	Cinematics.lock_player(false)
	_show_line()

func _show_line() -> void:
	var line: Dictionary = lines[index]
	name_label.text = str(line.get("name", ""))
	text_label.text = str(line.get("text", ""))
	text_label.visible_characters = 0
	_char_accum = 0.0
	hint_label.visible = false
	if line.has("darkness"):
		ColorFilter.set_darkness(float(line["darkness"]))
	if line.has("color"):
		ColorFilter.set_color(float(line["color"]))

func _process(delta: float) -> void:
	if not active:
		return
	if text_label.visible_characters < text_label.get_total_character_count():
		_char_accum += CHAR_SPEED * delta
		if _char_accum >= 1.0:
			var add := int(_char_accum)
			_char_accum -= add
			text_label.visible_characters += add
	else:
		hint_label.visible = true

func _input(event: InputEvent) -> void:
	if not active:
		return
	if not advance_armed:
		if not Input.is_action_pressed("interact"):
			advance_armed = true
		return
	if event.is_action_pressed("interact") or event.is_action_pressed("ui_accept"):
		advance_armed = false
		get_viewport().set_input_as_handled()
		if text_label.visible_characters < text_label.get_total_character_count():
			text_label.visible_characters = text_label.get_total_character_count()
		else:
			_advance()

func _advance() -> void:
	index += 1
	if index >= lines.size():
		_finish()
	else:
		_show_line()

func _finish() -> void:
	active = false
	$DialogueUI.visible = false
	Cinematics.unlock_player()
	finished.emit()
