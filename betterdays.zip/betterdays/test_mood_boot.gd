extends Node
## Scene-boot mood override for lighting test scenes.
## Attach to a scene and set boot_mood so ColorFilter boots at that mood
## instead of the default 0.5. (test_presunset.tscn uses boot_mood 0.0 = mode 1.)

@export var boot_mood := 0.0

func _ready() -> void:
	var cf := get_node_or_null("/root/ColorFilter")
	if cf and cf.has_method("set_mood"):
		cf.set_mood(boot_mood, 0.0)
