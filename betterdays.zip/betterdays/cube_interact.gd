extends StaticBody3D

func interact(_player: Node) -> void:
	DialogueManager.start_dialogue("office")
