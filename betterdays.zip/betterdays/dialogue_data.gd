class_name DialogueData
extends RefCounted
# No node attached, no autoload. Global class: use DialogueData.get_dialogue("key") anywhere.

const DIALOGUES := {
	"office": [
		{"name": "Patron", "text": "Bunu tekrar yapabileceğini düşünüyor musun?", "color": 0.7, "darkness": 0.2},
		{"name": "Patron", "text": "Seni bir süredir takip ediyorum... Bu çalışma değil.", "color": 0.4, "darkness": 0.32},
		{"name": "Patron", "text": "Kovuldun. Eşyalarını topla.", "color": 0.15, "darkness": 0.45},
	],
	"door": [
		{"name": "Baba", "text": "Oğlum... gelmişsin sonunda.", "darkness": 0.45},
		{"name": "Oğul", "text": "Baba... içeri girebilir miyim?", "darkness": 0.35},
		{"name": "Baba", "text": "Evet oğlum, burası senin evin. Hep öyleydi.", "darkness": 0.28},
	],
	"phone": [
		{"name": "", "text": "(Eski mesajlar... kimse yazmıyor artık.)", "darkness": 0.68},
		{"name": "", "text": "(Belki de hiç kimsenin aklına gelmiyorumdur.)", "darkness": 0.74},
	],
	"beach_memory": [
		{"name": "Baba", "text": "Şu çitlerin arkasında... sen çocukken orada balık tutardık.", "color": 0.12, "darkness": 0.35},
		{"name": "Baba", "text": "Denize ilk attığın oltayı hatırlıyor musun?", "color": 0.2, "darkness": 0.28},
	],
	"boat_catch_1": [
		{"name": "Baba", "text": "Kötü günler geçirdiğini biliyorum oğlum.", "color": 0.25, "darkness": 0.4},
		{"name": "Baba", "text": "Ama umudunu asla kaybetme. Sen bizim için çok önemlisin.", "color": 0.3, "darkness": 0.32},
	],
	"boat_catch_2": [
		{"name": "Baba", "text": "Görüyor musun? Birlikte daha iyiyiz.", "color": 0.45, "darkness": 0.2},
	],
	"boat_final": [
		{"name": "Baba", "text": "Daha iyi günlere bak oğlum.", "color": 0.7, "darkness": 0.05},
	],
	"obj_frame": [
		{"name": "", "text": "(Çerçevedeki fotoğraf: ben, baba ve deniz.)", "color": 0.63},
	],
	"obj_lamp": [
		{"name": "", "text": "(Eski lamba hâlâ aynı yerde duruyor.)"},
	],
	"obj_trophy": [
		{"name": "", "text": "(Balık yarışması kupası. En çok bu evi severdim.)", "color": 0.65},
	],
}

static func get_dialogue(key: String) -> Array:
	var v: Variant = DIALOGUES.get(key, [])
	return v if v is Array else []
