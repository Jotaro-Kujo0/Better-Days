extends Node
# Autoload "Cinematics". Locks input and/or swaps cameras for cutscenes/dialogue.

var _saved := {}

func lock_player(full: bool = false) -> void:
	var player := get_tree().get_first_node_in_group("player")
	if player == null:
		return
	if not _saved.has("player"):
		_saved["player"] = {
			"can_move": player.get("can_move"),
			"look_enabled": player.get("look_enabled"),
			"bob_enabled": player.get("bob_enabled"),
		}
	player.set("can_move", false)
	if full:
		player.set("look_enabled", false)
		player.set("bob_enabled", false)
	var cam := get_viewport().get_camera_3d()
	if cam and full:
		_saved["cam"] = cam

func unlock_player() -> void:
	var player := get_tree().get_first_node_in_group("player")
	if player != null and _saved.has("player"):
		player.set("can_move", _saved["player"]["can_move"])
		player.set("look_enabled", _saved["player"]["look_enabled"])
		player.set("bob_enabled", _saved["player"]["bob_enabled"])
	_saved.clear()

# Plays a camera animation. Returns when it ends. Usage (in any scene script):
#   await Cinematics.play_cutscene($CutsceneCamera, $CutAnimPlayer, "look_at_sea")
func play_cutscene(cut_cam: Camera3D, anim: AnimationPlayer, anim_name: String) -> void:
	var player := get_tree().get_first_node_in_group("player")
	lock_player(true)
	var prev_cam: Camera3D = get_viewport().get_camera_3d()
	if cut_cam != null:
		cut_cam.make_current()
		await get_tree().process_frame
	if anim != null:
		anim.play(anim_name)
		await anim.animation_finished
	if is_instance_valid(prev_cam):
		prev_cam.make_current()
		await get_tree().process_frame
	unlock_player()
